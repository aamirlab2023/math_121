import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

x = np.linspace(-5, 5, 25)
y = np.linspace(-5, 5, 25)
X, Y = np.meshgrid(x, y)

Z1 = (6-X-2*Y)/3
Z2 = (4-2*X-5*Y)/2
Z3 = 2-6*X+3*Y

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.plot_wireframe(X, Y, Z1)
ax.plot_wireframe(X, Y, Z2, color='r')
ax.plot_wireframe(X, Y, Z3, color='g')
ax.scatter(0, 0, 2, s=100, c='k')

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')


plt.show()
