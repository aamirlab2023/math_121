import numpy as np
import matplotlib.pyplot as plt

x1 = np.linspace(-0.5, 3.5, 100)
y1 = (11 - 3*x1)/2

x2 = x1
y2 = (1 - x2)/(-2)

plt.plot(x1, y1, '-b')
plt.plot(x2, y2, '-b')
#plt.plot([-0.5, 3.5], [0, 0], '-k')
#plt.plot([0, 0], [-0.5, 6.5], '-k')
plt.grid()
plt.show()
