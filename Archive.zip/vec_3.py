import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
# Define the starting point and vector components
# Create the plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

plt.quiver(0, 0, 0, 1, 2, 6, color='b', arrow_length_ratio=0.1)
plt.quiver(0, 0, 0, 2, 5, -3, color='b', arrow_length_ratio=0.1)
plt.quiver(0, 0, 0, 3, 2, 1, color='b', arrow_length_ratio=0.1)
plt.quiver(0, 0, 0, 6, 4, 2, color='k', arrow_length_ratio=0.1)



ax.set_xlim([-1, 5])
ax.set_ylim([-1, 5])
ax.set_zlim([-4, 5])
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# plt.xlim(-3, 16)
# plt.ylim(-3, 16)
#plt.xlabel('x-axis')
#plt.ylabel('y-axis')
#plt.title('Vector Plot')
#plt.grid(True)

# Draw the vector using plt.arrow()
#plt.arrow(0, 0, -2, 2, length_includes_head=True, head_width=0.2, head_length=0.3, fc='blue', ec='blue')
#plt.arrow(0, 0, 1, 3, length_includes_head=True, head_width=0.2, head_length=0.3, fc='blue', ec='blue')
#plt.arrow(0, 0, 3, 9, length_includes_head=True, head_width=0.2, head_length=0.3, fc='blue', ec='blue')
#plt.arrow(0, 0, 1, 11, length_includes_head=True, head_width=0.2, head_length=0.3, fc='black', ec='black')
#plt.plot([3, 1], [9, 11], 'r--')
#plt.plot([-2, 1], [2, 11], 'r--')
#plt.arrow(0, 0, 1, 3, head_width=0.2, head_length=0.3, fc='blue', ec='blue')
#plt.arrow(0, 0, 1, 11, head_width=0.2, head_length=0.3, fc='k', ec='k')
#plt.arrow(0, 0, 3, 9, head_width=0.2, head_length=0.3, fc='b', ec='b', linestyle='--')

# Plot the starting point
# plt.plot(start_point[0], start_point[1], 'ro', label='Start Point')

# Add labels and legend
# plt.legend()

# Show the plot
plt.show()
