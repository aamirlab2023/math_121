import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
# Define the starting point and vector components
# Create the plot
plt.figure(figsize=(4, 8))
# plt.xlim(-3, 16)
# plt.ylim(-3, 16)
plt.xlabel('x-axis')
plt.ylabel('y-axis')
plt.title('Vector Plot')
plt.grid(True)

# Draw the vector using plt.arrow()
plt.arrow(0, 0, -2, 2, length_includes_head=True, head_width=0.2, head_length=0.3, fc='blue', ec='blue')
plt.arrow(0, 0, 1, 3, length_includes_head=True, head_width=0.2, head_length=0.3, fc='blue', ec='blue')
plt.arrow(0, 0, 3, 9, length_includes_head=True, head_width=0.2, head_length=0.3, fc='blue', ec='blue')
plt.arrow(0, 0, 1, 11, length_includes_head=True, head_width=0.2, head_length=0.3, fc='black', ec='black')
plt.plot([3, 1], [9, 11], 'r--')
plt.plot([-2, 1], [2, 11], 'r--')
#plt.arrow(0, 0, 1, 3, head_width=0.2, head_length=0.3, fc='blue', ec='blue')
#plt.arrow(0, 0, 1, 11, head_width=0.2, head_length=0.3, fc='k', ec='k')
#plt.arrow(0, 0, 3, 9, head_width=0.2, head_length=0.3, fc='b', ec='b', linestyle='--')

# Plot the starting point
# plt.plot(start_point[0], start_point[1], 'ro', label='Start Point')

# Add labels and legend
# plt.legend()

# Show the plot
plt.show()
