> # Problem Statements

> ### Physical Information

 For a series circuit containing only a resistor and an inductor, Kirchhoff’s second law states that the sum of the voltage drop across the inductor $(L(di/dt))$ and the voltage drop across the resistor $(iR)$ is the same as the impressed voltage $(E(t))$ on the circuit. See Figure below.

![LR-series circuit](/home/aamir/Desktop/statements/lr.png)

Thus we obtain the linear differential equation for the current i(t),

$L \frac{di}{dt} + Ri = E(t)$

where $L$ and $R$ are known as the inductance and the resistance, respectively. The current $i(t)$ is also called the response of the system.

The voltage drop across a capacitor with capacitance $C$ is given by $q(t)/C$, where $q$ is the charge on the capacitor. Hence, for the series circuit shown in Figure below, Kirchhoff’s second law gives

$Ri + \frac{1}{C}q=E(t)$

![RC-series circuit](/home/aamir/Desktop/statements/rc.png)

But current $i$ and charge $q$ are related by $i=dq/dt$, so the above equation becomes the linear differential equation

$R \frac{dq}{dt}+\frac{1}{C}q = E (t)$

> ### Problem

A 12-volt battery is connected to a series circuit in which the inductance is 0.5 henry and the resistance is 10 ohm. Determine the current $i$ if the initial current is zero.

> ### Physical Information

Under the influence of gravity the outflowing water has velocity

$v(t)=0.600\sqrt{2gh(t)}$

where $h(t)$ is the height of the water above the hole at time $t$, and $g = 980 cm/sec^2 = 32.17 ft/sec^2$ is the acceleration of gravity at the surface of the earth.

![Leaking Tank](/home/aamir/Desktop/statements/lt.png)

> ### Problem

This is another prototype engineering problem that leads to an ODE. It concerns the outflow of water from a cylindrical tank with a hole at the bottom (Figure above). You are asked to find the height of the water in the tank at any time if the tank has diameter 2 m, the hole has diameter 1 cm, and the initial height of the water when the hole is opened is 2.25 m. When will the tank be empty?


